/*
                                   __
                               ___  \  \
                          ___  \  \  \  \    _______
                     ___  \  \  \  \  \__\__/_____  \
                     \  \  \  \  \__\_______      \__\____
                      \  \  \  \     ___ \  \________  \__/
                       \  \  \__\___/_  \ \___/   \  \___
                        \  \    ____  \  \________ \ ___/
                         \__\__/ \  \  \____/  \  \
                                  \  \     ___  \  \___
                                   \__\___/ \  \ \____/
                                           \  \
                                              \  \___
                 __                 _          \ ___/  _
                / _|_ __  ___  ___ | |____      ____ _| |_  ___  _ __
               | |_| '_ |/ _ \/ __|| '_ \ \ /\ / / _` | __|/ _ \| '__|
               |  _| |  |  __/\__ \| | | \ V  V / (_| | |_|  __/| |
               |_| |_|   \___||___/|_| |_|\_/\_/ \__,_|\__|\___||_|

            (C) 2 0 2 6   F r e s h w a t e r   I n s t r u m e n t s
*/

// clang-format off
#include "hardware.h"
#include <atomic>
#include <cerrno>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <initializer_list>
#include <portaudio.h>
#include <sys/select.h>
#include <termios.h>
#include <unistd.h>
#include <vector>

/* ---- pipes ------------------------------------------------------------- */

static int audio_requests[2] = {-1, -1}, audio_ready[2] = {-1, -1};
static int usb_port = -1, rs485_port = -1, ports[2] = {-1, -1};
static PaStream *stream;
static bool initialized;

[[noreturn]] static void io_error() {
  std::perror("simulator: I/O");
  std::_Exit(EXIT_FAILURE);
}
static void read_all(int fd, void *data, size_t size) {
  auto *bytes = static_cast<char *>(data);
  while (size) {
    ssize_t count = read(fd, bytes, size);
    if (count < 0 && errno == EINTR) continue;
    if (count == 0) errno = EPIPE;
    if (count <= 0) io_error();
    bytes += count;
    size -= count;
  }
}
static void write_all(int fd, const void *data, size_t size) {
  auto *bytes = static_cast<const char *>(data);
  while (size) {
    ssize_t count = write(fd, bytes, size);
    if (count < 0 && errno == EINTR) continue;
    if (count == 0) errno = EIO;
    if (count <= 0) io_error();
    bytes += count;
    size -= count;
  }
}
static void close_fd(int &fd) {
  if (fd >= 0) close(fd);
  fd = -1;
}
static bool setup_select(int usb = -1, int rs485 = -1) {
  ports[0] = usb;
  ports[1] = rs485;
  if (pipe(audio_requests) < 0 || pipe(audio_ready) < 0) return false;
  for (int fd : {usb, rs485, audio_requests[0]}) {
    if (fd >= FD_SETSIZE) { errno = EINVAL; return false; }
  }
  for (int *pipe : {audio_requests, audio_ready}) for (unsigned i = 0; i < 2; ++i)
    if (fcntl(pipe[i], F_SETFD, FD_CLOEXEC) < 0) return false;
  return true;
}
static void close_select() {
  for (int *pipe : {audio_requests, audio_ready}) for (unsigned i = 0; i < 2; ++i)
    close_fd(pipe[i]);
  ports[0] = ports[1] = -1;
}

/* ---- serial input ------------------------------------------------------ */

static std::vector<uint8_t> usb_input, rs485_input;

static bool open_serial_port(int &port, int &client, const char *label) {
  port = posix_openpt(O_RDWR | O_NOCTTY | O_NONBLOCK);
  if (port < 0 || grantpt(port) < 0 || unlockpt(port) < 0) return false;
  const char *path = ptsname(port);
  if (!path || (client = open(path, O_RDWR | O_NOCTTY | O_NONBLOCK)) < 0) return false;
  termios mode;
  if (tcgetattr(client, &mode) < 0) return false;
  cfmakeraw(&mode);
  mode.c_cflag |= CLOCAL | CREAD;
  if (tcsetattr(client, TCSANOW, &mode) < 0) return false;
  std::printf("%s: %s\n", label, path);
  std::fflush(stdout);
  return true;
}
static void close_serial_port(int &port, int &client) { close_fd(port); close_fd(client); }
static void process_serial(int port, std::vector<uint8_t> &input) {
  unsigned char bytes[256];
  ssize_t count = read(port, bytes, sizeof bytes);
  if (count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)) return;
  if (count == 0) errno = EPIPE;
  if (count <= 0) io_error();
  input.insert(input.end(), bytes, bytes + count);
}

/* ---- wait for serial input or one audio token --------------------------- */

static void wait_select() {
  static char last_in_batch = 0;
  if (last_in_batch) {
    write_all(audio_ready[1], &last_in_batch, 1);
    last_in_batch = 0;
  }
  fd_set watched{}, ready;
  FD_SET(audio_requests[0], &watched);
  int highest = audio_requests[0];
  for (int fd : ports) {
    if (fd < 0) continue;
    FD_SET(fd, &watched);
    if (fd > highest) highest = fd;
  }
  int count;
  do {
    ready = watched;
    count = select(highest + 1, &ready, nullptr, nullptr, nullptr);
  } while (count < 0 && errno == EINTR);
  if (count < 0) io_error();
  if (FD_ISSET(audio_requests[0], &ready)) read_all(audio_requests[0], &last_in_batch, 1);
}

/* ---- generate and play a sine wave ------------------------------------- */

static int32_t audio_buffers[BUF_COUNT][AUDIO_BUFFER_FRAMES];
static std::atomic<uint64_t> write_index{0}, read_index{0};

static void generate_audio_samples() {
  const auto index = write_index.load(std::memory_order_relaxed);
  if (index - read_index.load(std::memory_order_acquire) == BUF_COUNT) return;
  static double phase = 0;
  constexpr double tau = 6.28318530717958647692;
  for (auto &sample : audio_buffers[index % BUF_COUNT]) {
    sample = static_cast<int32_t>(std::sin(phase) * (INT32_MAX / 4.0));
    phase += tau * 440.0 / AUDIO_SAMPLE_RATE_HZ;
    if (phase >= tau) phase -= tau;
  }
  write_index.store(index + 1, std::memory_order_release);
}
static int audio_callback(const void *, void *output, unsigned long,
                          const PaStreamCallbackTimeInfo *, PaStreamCallbackFlags, void *) {
  char tokens[BUF_COUNT]{};
  tokens[BUF_COUNT - 1] = 1; // Acknowledge the batch after its final generation pass.
  write_all(audio_requests[1], tokens, sizeof tokens);
  char ready;
  read_all(audio_ready[0], &ready, 1);
  const auto end = write_index.load(std::memory_order_acquire);
  if (end - read_index.load(std::memory_order_relaxed) != BUF_COUNT) { errno = EPROTO; io_error(); }
  std::memcpy(output, audio_buffers, sizeof audio_buffers);
  read_index.store(end, std::memory_order_release);
  return paContinue;
}
static bool open_audio() {
  PaError error = Pa_Initialize();
  if (error == paNoError) {
    initialized = true;
    error = Pa_OpenDefaultStream(&stream, 0, 1, paInt32, AUDIO_SAMPLE_RATE_HZ,
                                 BUF_COUNT * AUDIO_BUFFER_FRAMES, audio_callback, nullptr);
    if (error == paNoError) error = Pa_StartStream(stream);
    else stream = nullptr;
  }
  if (error != paNoError) std::fprintf(stderr, "simulator: audio: %s\n", Pa_GetErrorText(error));
  return error == paNoError;
}
static bool close_audio() {
  PaError error = stream ? Pa_CloseStream(stream) : paNoError;
  stream = nullptr;
  PaError termination = initialized ? Pa_Terminate() : paNoError;
  initialized = false;
  if (error != paNoError) std::fprintf(stderr, "simulator: audio: %s\n", Pa_GetErrorText(error));
  if (termination != paNoError) std::fprintf(stderr, "simulator: audio: %s\n", Pa_GetErrorText(termination));
  return error == paNoError && termination == paNoError;
}

/* ---- run the simulator -------------------------------------------------- */

int main() {
  int usb_client = -1, rs485_client = -1;
  if (!open_serial_port(usb_port, usb_client, "USB") ||
      !open_serial_port(rs485_port, rs485_client, "RS485") || !setup_select(usb_port, rs485_port))
    std::perror("simulator: setup");
  else if (open_audio()) while (true) {
    wait_select();
    process_serial(rs485_port, rs485_input);
    process_serial(usb_port, usb_input);
    generate_audio_samples();
  }
  close_audio();
  close_select();
  close_serial_port(rs485_port, rs485_client);
  close_serial_port(usb_port, usb_client);
  return 1;
}
// clang-format on
